package TestRunner;

public class entcustomer {

}
