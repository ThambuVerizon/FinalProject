package TestRunner;

public class customer {

}
